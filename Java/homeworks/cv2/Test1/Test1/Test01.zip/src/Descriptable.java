interface Descriptable {
    public String getDescription();
}