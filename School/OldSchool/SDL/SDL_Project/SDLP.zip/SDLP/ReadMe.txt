Hello.
Welcome to my Breakout Game ! 

When you open the Breakout.exe file, you will be presented with a menu.
The menu consists of:
"Play" button which starts the game,
"Settings" button to customise paddle color, ball color and difficulty,
"Hall of Fame" which is not finished yet but it soon will be
and "Quit" button which ends the program. 

After you set you desired difficulty and colors, head into the menu and press Play.
The game will immediately start. The goal of the game is to destroy all tiles and get
the highest score possible. You get points for catching the ball with the paddle and
for destroying the tiles. 

Paddle movement is managed by "a" (move left) and "d" (move right)

Enjoy !