#pragma once
#include <math.h>

class Node
{
private:
    int value;
    Node *leftSubTree;
    Node *rightSubTree;

public:
    Node(int value, Node *left, Node *right);
    int getValue();
    void addLeftSubTree(Node *node);
    void addRightSubTree(Node *node);
};