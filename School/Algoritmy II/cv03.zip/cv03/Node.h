#pragma once
#include "Node.cpp"
#include <iostream>

Node::Node(int value, Node *left, Node *right)
{
    this->value = value;
    this->leftSubTree = left;
    this->rightSubTree = right;
}

int Node::getValue()
{
    return this->value;
}

void Node::addLeftSubTree(Node *node)
{
    this->leftSubTree = node;
}

void Node::addRightSubTree(Node *node)
{
    this->rightSubTree = node;
}