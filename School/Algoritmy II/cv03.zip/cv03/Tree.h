#pragma once
#include "Tree.cpp"

Tree::Tree()
{
    this->nodeAmount = 0;
}

void Tree::addNode(Node *node)
{
    this->nodes.push_back(node);
    this->nodeAmount++;
}

void Tree::printTree()
{
}

void Tree::sortAVLTree()
{
    Node *temp[this->nodeAmount];

    for (int i = 0; i < this->nodes.size(); i++)
        temp[i] = this->nodes[i];

    for (int i = 0; i < this->nodeAmount; i++)
        this->nodes.pop_back();

    int position = 0;

    Node *maxNode = new Node(INT_MAX, NULL, NULL);

    for (int j = 0; j < this->nodeAmount; j++)
    {
        int val = INT_MAX;
        for (int i = 0; i < this->nodeAmount; i++)
        {
            if (temp[i]->getValue() < val && temp[i] != NULL)
            {
                val = temp[i]->getValue();
                position = i;
            }
        }
        this->nodes.push_back(temp[position]);
        temp[position] = maxNode;
    }

    for (int i = 0; i < this->nodeAmount; i++)
    {
        std::cout << this->nodes[i]->getValue() << std::endl;
    }

    this->topNode = this->nodes[this->nodeAmount / 2];
    std::cout << "Top node is : " << this->topNode->getValue() << std::endl;

    this->topNode->addLeftSubTree(this->nodes[this->nodeAmount / 4]);
    this->topNode->addLeftSubTree(this->nodes[(this->nodeAmount / 4) * 3]);

    Node *leftTree = this->nodes[this->nodeAmount / 4];

    Node *rightTree = this->nodes[(this->nodeAmount / 4) * 3];
}