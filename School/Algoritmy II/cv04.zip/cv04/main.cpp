#include "Heap.cpp"

int main(int argc, char const *argv[])
{

    std::vector<int> values = {5, 8, 12, 14, 16, 18, 22, 26, 31, 35, 38, 40, 41, 44, 45, 47, 50, 51, 55};

    Heap *heap = new Heap();

    return 0;
}
